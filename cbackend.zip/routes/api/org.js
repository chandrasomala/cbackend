const express = require('express');
const router = express.Router();
const multer = require('multer');
const bcrypt = require('bcryptjs');

//importing Org modal
const Org = require('../../models/Org')

const storage = multer.diskStorage({
    destination : (req,file,cb)=>{
      cb(null,'./uploads/');
    },
    filename : (req,file,cb)=>{
      const now = new Date().toISOString();
      const date = now.replace(/:/g,'-')
      cb(null, date + file.originalname)
    }
  })
  
  const fileFilter = (req,file,cb)=>{
    if(file.mimetype === 'image/jpeg' || file.mimetype === 'image/png'
    ||file.mimetype === 'image/png'){
        cb(null,true);
    }else{
      cb(new Error('Only png,jpg and jpeg file is accepted'),false)
    }
  }
  
  
  const upload= multer( {storage : storage,
                          limits:{
                              fileSize :  1024 * 1024 *5
                          },
                          fileFilter:fileFilter}) 

//Test route
router.get('/test', (req, res) => {
    res.json({
      message: "Everything is okay"
    })
  })

//register routes
router.post('/registerOrg',upload.single('orgimage'),(req,res)=>{
  
    Org.findOne({email: req.body.email}).then(user =>{
       if(user){
        return res.status(400).json({email : "Email already exist"})
      }else{
          const newOrg = new Org({
          name : req.body.name,
          email : req.body.email,
          orgtype : req.body.orgtype,
          orgimage :req.file.path,
          password : req.body.pass,
          estyear: req.body.estyear,
          GSTIN: req.body.GSTIN,
          PAN: req.body.PAN,
          MOA: req.body.MOA
        }); 
        console.log(newOrg)
        bcrypt.genSalt(10,(err,salt)=>{
          bcrypt.hash(newOrg.password,salt,(err,hash)=>{
            if(err) throw err
            newOrg.password = hash,
            newOrg.save()
            .then(org => res.json(org))
            .catch(err => console.log(err))
          })
        })
      }
    })
  })

//login route

router.post('/loginOrg',(req,res)=>{
    email = req.body.email;
    password = req.body.pass;
  
    console.log(req.body.pass)
    Org.findOne({email}).then(user => {
      if(!user){
        res.json({email:"Email not found"})
      }
  
      bcrypt.compare(password, user.password)
      .then(isMatch=>{
        if(isMatch){
        res.json({msg:" Login Success"})
      } else{
        return res.status(400).json({password : "Password Incorrect"});
      }
      })
    })
  })

  module.exports = router