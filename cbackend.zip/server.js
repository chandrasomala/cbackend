const express = require('express');
const app = express();
const mongoose = require('mongoose');
const users = require('./routes/api/users')
const org = require('./routes/api/org')
const profile = require('./routes/api/profile')
const posts = require('./routes/api/posts')
const bodyParser = require('body-parser')

// DB config

const db = require('./config/keys').mongoURL;
mongoose
  .connect(db, {
    useNewUrlParser: true
  })
  .then(() => console.log("Mongodb connected"))
  .catch((err) => console.log(err))


app.get('/', (req, res) => {
  res.send('Hello from test route')
})

app.use(bodyParser.urlencoded({extended:false}))
app.use(bodyParser.json());
app.use('/api/users', users);
app.use('/api/org', org);
app.use('/api/profile', profile);
app.use('/api/posts', posts);

const port = process.env.PORT || 5000;
app.listen(port, () => console.log(`Server is running on port ${port}`));